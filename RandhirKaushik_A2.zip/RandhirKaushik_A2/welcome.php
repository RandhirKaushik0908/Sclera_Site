<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register SSBC 2020</title>
    <meta charset="utf-8">
    <meta content="SSBC 2020" name="description">
    <meta content="SSBC" name="description">
    <meta content="SSRBC" name="description">
    <meta content="SSERBC" name="description">
    <meta content="BTAS" name="description">
    <meta content="ICB" name="description">
    <meta content="IJCB" name="description">
    <meta content="Randhir Kaushik" name="author">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- Font-->
    <link rel="stylesheet" type="text/css" href="css/opensans-font.css">
    <link rel="stylesheet" type="text/css" href="fonts/line-awesome/css/line-awesome.min.css">
    <!-- Jquery -->
    <link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
    <!-- Main Style Css -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body class="form-v4">
<div class="header">
    <img alt="SSBC 2020 Logo" class="img-responsive" src="images/logo_banner.png"
         style="display: block;  margin-left: auto; margin-right: auto; ">
</div>

<!-- Site Navigation Menu -->
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button class="navbar-toggle" data-target="#NavMenu" data-toggle="collapse" type="button">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">SSBC 2020 </a>
        </div>
        <div class="collapse navbar-collapse" id="NavMenu">
            <ul class="nav navbar-nav">
                <li><a href="home.html">Home</a></li>
                <li><a href="dataset.html">Dataset Description</a></li>
                <li><a href="schedule.html">Schedule</a></li>
                <li><a href="news.html">News and Result</a></li>
                <li><a href="gallery.html">Gallery</a></li>
                <li class="active"><a href="register.html">Submit</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="form-v4-content form-left">
        <p class="text-1">
            Welcome <?php echo $_POST["name"]; ?>
            <br>
            Your email address is: <?php echo $_POST["email"]; ?>
            <br>
        </p>
        <div class="form-left-last">
            <div class="button">
                <a href="samples.zip"> Download Samples</a>
                <a href="submit.html"> NEXT </a>
            </div>
            <br>
        </div>
    </div>
</div>
<footer>
    <div class="panel-footer text-center">
        <p>&copy;Randhir Kaushik, <a href="http://www.jcu.edu.au" target="_blank">James Cook University</a></p>
    </div>
</footer>

</body>
</html>
